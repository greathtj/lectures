# Ohmy ImClass
Image classification suite