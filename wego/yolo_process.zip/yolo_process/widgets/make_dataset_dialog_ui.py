# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'make_dataset_dialog.ui'
##
## Created by: Qt User Interface Compiler version 6.9.1
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide6.QtCore import (QCoreApplication, QDate, QDateTime, QLocale,
    QMetaObject, QObject, QPoint, QRect,
    QSize, QTime, QUrl, Qt)
from PySide6.QtGui import (QBrush, QColor, QConicalGradient, QCursor,
    QFont, QFontDatabase, QGradient, QIcon,
    QImage, QKeySequence, QLinearGradient, QPainter,
    QPalette, QPixmap, QRadialGradient, QTransform)
from PySide6.QtWidgets import (QApplication, QDialog, QSizePolicy, QWidget)

class Ui_DialogMakeDataset(object):
    def setupUi(self, DialogMakeDataset):
        if not DialogMakeDataset.objectName():
            DialogMakeDataset.setObjectName(u"DialogMakeDataset")
        DialogMakeDataset.resize(797, 662)

        self.retranslateUi(DialogMakeDataset)

        QMetaObject.connectSlotsByName(DialogMakeDataset)
    # setupUi

    def retranslateUi(self, DialogMakeDataset):
        DialogMakeDataset.setWindowTitle(QCoreApplication.translate("DialogMakeDataset", u"Dialog", None))
    # retranslateUi

